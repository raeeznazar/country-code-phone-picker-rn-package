import type { PhoneNumberInputProps } from './types';
/**
 * A phone number field with an attached, searchable country code picker — the trigger and the
 * input render as two separate rounded boxes side by side.
 *
 * Validation/length are per-country aware but deliberately simple by default (see `maxLength` and
 * `validator` in the README) — for real-world validation, pass a `validator` built on a library
 * like `libphonenumber-js`.
 */
export declare function PhoneNumberInput({ value, defaultValue, onChangeText, onChange, country, defaultCountry, onChangeCountry, countries, preferredCountries, includeCountries, excludeCountries, maxLength, validator, formatter, placeholder, keyboardType, autoFocus, disabled, onSubmitEditing, error, style, title, searchPlaceholder, emptyText, closeAccessibilityLabel, snapPoints, renderTrigger, renderCountryRow, }: PhoneNumberInputProps): React.JSX.Element;
