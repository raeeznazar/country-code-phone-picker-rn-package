import type { Country } from './types';
/**
 * Default country list — ISO 3166-1 alpha-2 code, English name, E.164 dial code, flag emoji.
 * Pass your own `countries` prop to replace this entirely, or use `includeCountries` /
 * `excludeCountries` / `preferredCountries` to filter and reorder it instead of replacing it.
 */
export declare const DEFAULT_COUNTRIES: Country[];
export declare function findCountry(countries: Country[], isoCode: string | undefined): Country | undefined;
export interface BuildCountryListOptions {
    countries?: Country[];
    preferredCountries?: string[];
    includeCountries?: string[];
    excludeCountries?: string[];
}
/** Applies `includeCountries` / `excludeCountries` / `preferredCountries` to a base list. */
export declare function buildCountryList({ countries, preferredCountries, includeCountries, excludeCountries, }: BuildCountryListOptions): Country[];
