import type { Country, PhoneValue } from './types';
export declare function digitsOnly(value: string): string;
/** The longest a national significant number can be under E.164. Used as the default typing cap. */
export declare const DEFAULT_MAX_LENGTH = 15;
export declare function resolveMaxLength(maxLength: number | (Partial<Record<string, number>> & {
    default?: number;
}) | undefined, country: Country): number;
/** Default `isValid`: just "has the user typed something". Pass your own `validator` for real rules. */
export declare function defaultValidator(nationalNumber: string): boolean;
export declare function buildPhoneValue(country: Country, nationalNumber: string, validator?: (nationalNumber: string, country: Country) => boolean): PhoneValue;
