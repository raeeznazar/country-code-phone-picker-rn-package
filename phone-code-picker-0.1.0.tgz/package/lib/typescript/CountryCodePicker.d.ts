import type { CountryCodePickerProps } from './types';
/**
 * A trigger button (flag + dial code) that opens a searchable bottom sheet of countries.
 *
 * Renders its own `BottomSheetModal` with `enableDynamicSizing={false}` and fixed `snapPoints`
 * rather than relying on the library's default dynamic sizing — dynamic sizing measures a sheet's
 * height off its *initially rendered* content, which for a long `BottomSheetFlatList` is only the
 * first virtualized screenful. Without this, the list looks "stuck" after a handful of rows.
 *
 * Needs `BottomSheetModalProvider` (from `@gorhom/bottom-sheet`) somewhere above it in the tree —
 * see the package README for setup.
 */
export declare function CountryCodePicker({ countries, country, defaultCountry, onSelect, preferredCountries, includeCountries, excludeCountries, title, searchPlaceholder, emptyText, closeAccessibilityLabel, snapPoints, style, renderTrigger, renderCountryRow, disabled, }: CountryCodePickerProps): React.JSX.Element;
